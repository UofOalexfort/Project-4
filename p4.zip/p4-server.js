// Require the Fastify framework and instantiate it
const fastify = require("fastify")();
const fs = require("fs");

//-------------------------------------------------------------------------------------------
//Import functions

const {
    getQuestions,
    getAnswers,
    getQuestionsAnswers,
    getQuestion,
    getAnswer,
    getQuestionAnswer,
    } = require("./p4-module.js");

//-------------------------------------------------------------------------------------------
// get route - cit/question

    fastify.get("/cit/question", (request, reply) => {
            reply
              .code(200)
              .header("Content-Type", "application/json; charset=utf-8")
              .send({error:"", statusCode:200, questions: getQuestions()});              
          }
      );

//-------------------------------------------------------------------------------------------
//get route - cit/answer

fastify.get("/cit/answer", (request, reply) => {
    reply
      .code(200)
      .header("Content-Type", "application/json; charset=utf-8")
      .send({error:"", statusCode:200, answers: getAnswers()});              
  }
);

//-------------------------------------------------------------------------------------------
//get route - cit/questionanswer

fastify.get("/cit/questionanswer", (request, reply) => {
    reply
      .code(200)
      .header("Content-Type", "application/json; charset=utf-8")
      .send({error:"", statusCode:200, questions_answers: getQuestionsAnswers()});              
  }
);

//-------------------------------------------------------------------------------------------
//get route - cit/question/:number

fastify.get("/cit/question/:number", (request, reply) => {              //: indicates that the follow is a parameter
    let {number} = request.params
    reply
      .code(200)
      .header("Content-Type", "application/json; charset=utf-8")
      .send({error:"", statusCode:200, questions: getQuestion(parseInt(number))});              
  }
);



//-------------------------------------------------------------------------------------------
//get route - cit/answer/:number

fastify.get("/cit/answer/:number", (request, reply) => {
    let {number} = request.params
    reply
      .code(200)
      .header("Content-Type", "application/json; charset=utf-8")
      .send({error:"", statusCode:200, questions: getAnswer(parseInt(number))});              
  }
);

//-------------------------------------------------------------------------------------------
//get route - cit/questionanswer/:number

fastify.get("/cit/questionanswer/:number", (request, reply) => {
    const {number} = request.params
    const q = getQuestionAnswer(parseInt(number));

    reply
      .code(200)
      .header("Content-Type", "application/json; charset=utf-8")
      .send({error:"", statusCode:200, question: q.question, answer: q.answer});              
  });

//-------------------------------------------------------------------------------------------
//unmatched route

fastify.get("*", (request, reply) => {
    reply
      .code(404)
      .header("Content-Type", "application/json; charset=utf-8")
      .send({error:"Route Not found", statusCode: 404});              
  }
);

//-------------------------------------------------------------------------------------------

// Start server and listen to requests using Fastify

const listenIP = "localhost";
const listenPort = 8080;
fastify.listen(listenPort, listenIP, (err, address) => {
  if (err) {
    console.log(err);
    process.exit(1);
  }
  console.log(`Server listening on ${address}`);
});

