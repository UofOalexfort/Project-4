
const {data} = require('./p4-data.js');

//------------------------------------------------

 //GetQuestions
    //Returns an array of strings where each array element is a question.
    //[ 'Q1', 'Q2', 'Q3' ]
function getQuestions(){
const questions = [];
for(const quest of data){
    questions.push(quest.question);
}
return questions;
};
console.log(getQuestions());

//------------------------------------------------

//getAnswers
    //Returns an array of strings where each array element is an answer.
    //[ 'A1', 'A2', 'A3' ]
function getAnswers(){
const answers = [];
for(const ans of data){
    answers.push(ans.answer);
}
return answers;

};
console.log(getAnswers());

//------------------------------------------------

//getQuestionsAnswered
    //Returns a copy of the original data array of objects.
   /*  [
        { question: 'Q1', answer: 'A1' },
        { question: 'Q2', answer: 'A2' },
        { question: 'Q3', answer: 'A3' }
      ] */
      
function getQuestionsAnswers(){
    return data.map(( item ) => {               
    return { ...item };                         
});
}
console.log(getQuestionsAnswers());
 
//------------------------------------------------

//getQuestionNumber()
    //Returns an object with the following properties:
    //question property (string): The question from the data.
    //number property (integer): The question number,  not array index value.
    //error message property (string): Any error that occurred while getting the question.
 
    function getQuestion(number = ''){
        let questionObj = {                                     //object with empty strings to hold the new values
            question: "",
            number: "",
            error: "",
        };
        
    //if number param is not a number:
    if( !Number.isInteger(number) ){
        questionObj.error = "number must be an integer";        //set questionObj.error equal to the follow string depending on the results of the if statement
        console.log("number must be an integer");               //comment out later
    }
    //if number param is greater thanb number of questions in data:
    else if(number > 3){
        questionObj.error = "number must be less than 3";       //set questionObj.error equal to the follow string depending on the results of the if statement
        console.log("number must be less than 3");              //comment out later
    }
    //if number param is less than the number of questions in data:
    else if(number <= 0){
        questionObj.error = "number must be greater than 0";    //set questionObj.error equal to the follow string depending on the results of the if statement
        console.log("number must be greater than 0");           //comment out later
    }
    else{
        index = number -1;
    questionObj.number = number;                           //set questionObj.number (within question object) equal to the value we give to number param
    questionObj.question = data[index].question;       //set questionObj.question (within question object) equal to the indexing value we give to number param (of data) -1. so if num param = 1, then it will return array index 0
    }
    //return new object
return questionObj
    };
    console.log(getQuestion(2));

//------------------------------------------------

    //getAnswer(number = ""):
        //Returns an object with the following properties:
        //answer property (string): The answer from the data.
        //number property (integer): The question number,  not array index value.
        //error message property (string): Any error that occurred while getting the question.

    function getAnswer(number = ''){
        let answerObj = {                                     //object with empty strings to hold the new values
            answer: "",
            number: "",
            error: "",
        };
        
    //if number param is not a number:
    if( !Number.isInteger(number) ){
        answerObj.error = "number must be an integer";        //set answerObj.error equal to the follow string depending on the results of the if statement
        console.log("number must be an integer");               //comment out later
    }
    //if number param is greater thanb number of answers in data:
    else if(number > 3){
        answerObj.error = "number must be less than 3";       //set answerObj.error equal to the follow string depending on the results of the if statement
        console.log("number must be less than 3");              //comment out later
    }
    //if number param is less than the number of answers in data:
    else if(number <= 0){
        answerObj.error = "number must be greater than 0";    //set questionObj.error equal to the follow string depending on the results of the if statement
        console.log("number must be greater than 0");           //comment out later
    }
    else{
        index = number -1;
    answerObj.number = number;                           //set answerObj.number (within answer object) equal to the value we give to number param
    answerObj.answer = data[index].answer;       //set answerObj.answer (within answer object) equal to the indexing value we give to number param (of data) -1. so if num param = 1, then it will return array index 0
    }
    //return new object
return answerObj
    };
    console.log(getAnswer(2));

//------------------------------------------------

//getQuestionAnswer(number = ""):
    //Returns an object with the following properties:
    //question property (string): The question from the data.
    //answer property (string): The answer from the data.
    //number property (integer): The question number,  not array index value.
    //error message property (string): Any error that occurred while getting the question.
function getQuestionAnswer(number = ""){ 
    const questionAnswerObj = {
        question: "",
        answer: "",
        number: "",
        error: "",
    };

    if( !Number.isInteger(number) ){
        questionAnswerObj.error = "number must be an integer";           //set answerObj.error equal to the follow string depending on the results of the if statement
        console.log("number must be an integer");               //comment out later
    }
    //if number param is greater thanb number of answers in data:
    else if(number > 3){
        questionAnswerObj.error = "number must be less than 3";       //set answerObj.error equal to the follow string depending on the results of the if statement
        console.log("number must be less than 3");              //comment out later
    }
    //if number param is less than the number of answers in data:
    else if(number <= 0){
        questionAnswerObj.error = "number must be greater than 0";    //set questionObj.error equal to the follow string depending on the results of the if statement
        console.log("number must be greater than 0");           //comment out later
    }

else{
index = number -1;
questionAnswerObj.number = number;                           //set answerObj.number (within answer object) equal to the value we give to number param
questionAnswerObj.answer = data[index].answer;
questionAnswerObj.question = data[index].question;
}

return questionAnswerObj 
};
console.log(getQuestionAnswer());

//-------------------------------------------------------------------------------------------

//Export functions

module.exports = {
    getQuestions,
    getAnswers,
    getQuestionsAnswers,
    getQuestion,
    getAnswer,
    getQuestionAnswer,
}

//-------------------------------------------------------------------------------------------


//-------------------------------------------------------------------------------------------
/*****************************
  Module function testing
******************************/
function testing(category, ...args) {
    console.log(`\n** Testing ${category} **`);
    console.log("-------------------------------");
    for (const o of args) {
      console.log(`-> ${category}${o.d}:`);
      console.log(o.f);
    }
  }
  
  // Set a constant to true to test the appropriate function
  const testGetQs = false;
  const testGetAs = false;
  const testGetQsAs = false;
  const testGetQ = false;
  const testGetA = false;
  const testGetQA = false;
  const testAdd = false;      // Extra credit
  const testUpdate = false;   // Extra credit
  const testDelete = false;   // Extra credit

//-------------------------------------------------------------------------------------------

  // getQuestions()
if (testGetQs) {
    testing("getQuestions", { d: "()", f: getQuestions() });
  }
  
  // getAnswers()
  if (testGetAs) {
    testing("getAnswers", { d: "()", f: getAnswers() });
  }
  
  // getQuestionsAnswers()
  if (testGetQsAs) {
    testing("getQuestionsAnswers", { d: "()", f: getQuestionsAnswers() });
  }
  
  // getQuestion()
  if (testGetQ) {
    testing(
      "getQuestion",
      { d: "()", f: getQuestion() },      // Extra credit: +1
      { d: "(0)", f: getQuestion(0) },    // Extra credit: +1
      { d: "(1)", f: getQuestion(1) },
      { d: "(4)", f: getQuestion(4) }     // Extra credit: +1
    );
  }
  
  // getAnswer()
  if (testGetA) {
    testing(
      "getAnswer",
      { d: "()", f: getAnswer() },        // Extra credit: +1
      { d: "(0)", f: getAnswer(0) },      // Extra credit: +1
      { d: "(1)", f: getAnswer(1) },
      { d: "(4)", f: getAnswer(4) }       // Extra credit: +1
    );
  }
  
  // getQuestionAnswer()
  if (testGetQA) {
    testing(
      "getQuestionAnswer",
      { d: "()", f: getQuestionAnswer() },    // Extra credit: +1
      { d: "(0)", f: getQuestionAnswer(0) },  // Extra credit: +1
      { d: "(1)", f: getQuestionAnswer(1) },
      { d: "(4)", f: getQuestionAnswer(4) }   // Extra credit: +1
    );
  }
  